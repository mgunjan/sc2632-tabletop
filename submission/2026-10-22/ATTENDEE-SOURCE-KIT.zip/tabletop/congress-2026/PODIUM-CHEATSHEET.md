# SC2632 presenter field guide

**October 26, 2026 | 4:30–5:30 PM | Milind Gunjan and Vivek Mayuranathan**

## Opening: set the room before the exercise

**Milind, slides 1–6 (00:00–03:30).** Start with the operational conflict, then orient the room: one fictional shared Kubernetes platform, AI agents as workloads, and a separate copilot proposing controls. The payment API is a teaching scenario because it gives teams a concrete service floor (three copies, at least two healthy); the cases teach generic Kubernetes boundaries, not payment compliance. Nothing is assigned as the incident until teams choose on slide 13.

> “A green policy PR can still leave live traffic and API permissions exposed. Your table must decide what to stop, what to preserve, and what evidence would justify containment.”

Plain-language translations: a cluster is a shared platform; a namespace is a resource group; a Pod is a running workload; a replica is another copy; a ServiceAccount is a workload's Kubernetes API identity. Falco and API audit are detection sources; Kyverno checks proposed resources before they start; NetworkPolicy controls pod traffic; RBAC controls Kubernetes API actions. Each has a different boundary.

**Vivek, slides 7–8 (03:30–05:30).** Explain the bounded Python harness and its trust boundary. The model returns a typed choice; it does not deploy. **Milind, slides 9–10 (05:30–07:15).** Trace one supplied intent clause to a tested control, then point to the uncovered requirements. **Vivek, slide 11 (07:15–08:15).** Introduce Q0–Q3 as a human-declared posture, with verification per layer. **Both, slides 12–14 (08:15–12:00).** Orient the paper record, assign the case and roles, and set the operating constraint.

Falco boundary: rules passed static validation and audit-rule synthetic tests, but live capture, API-server delivery and alert-to-response are not exercised. The workshop does not integrate Falco with the policy copilot or automatically trigger quarantine.

## Minute-by-minute run of show

| Elapsed | Slides | Lead | What the room does |
|---|---:|---|---|
| 00–03:30 | 1–6 | Milind | Set the stakes, why this scenario, what is known/unknown, platform map and control boundaries. |
| 03:30–05:30 | 7–8 | Vivek | Separate Python orchestration from model choice; explain inputs and trust boundary. |
| 05:30–07:15 | 9–10 | Milind | Follow one intent clause to a test; identify what it does not cover. |
| 07:15–08:15 | 11 | Vivek | Explain Q0–Q3 and the need for human authority and per-layer checks. |
| 08:15–12:00 | 12–14 | Both | Show pages 6–7, assign one case, name roles, choose a constraint and service floor. |
| 12–16 | 15 | Milind | Draft behavior to stop, identity, dependency to preserve and service floor. |
| 16–20 | 16 | Vivek | Approve / modify / reject / escalate; state one change and one missing test. |
| 20–23 | 17 | Milind | Review the exception: approver, exact scope, owner, expiry and revocation check. |
| 23–27 | 18 | Vivek | Set Audit / Warn / Deny per control and a measurable promotion test. |
| 27–28 | — | Both | Transition; keep the short buffer visible. |
| 28–35 | 19 | Both | Open sealed page 8; order evidence, containment scope, service floor and verification. |
| 35–39 | 20 | Milind | Open sealed page 9; revise or defend the plan and state which fact matters. |
| 39–45 | 21–25 | Milind / Vivek | Predict, then reveal four recorded k3s observations. Slide 23 is a capacity stall, not a deadlock. |
| 45–46 | 26; backup 35 | Vivek | Compare a locked Case D prediction with a separate recorded synthetic result. |
| 46–49 | 27 | Both | Review CONTROL-REVIEW page 1; keep page 2 sealed. Name test scope, missing evidence and owner. |
| 49–51 | 28–29 | Milind | Reveal incomplete coverage; one rule passed 6/6 checks, three intent clauses remain unresolved. |
| 51–55 | 30 | Both | Define recovery evidence, rollback criteria and who can lift each posture. |
| 55–60 | 31–32 | Both | Compare the illustrative record, choose a take-home action, owner and verification; Q&A. |

Keep decision pages sealed until the matching prompt. Hear no more than two 20-second reports per round. Credit a justified hold when evidence is missing; do not award points for maximum lockdown. The four roles are incident lead, recorder, evidence analyst and independent reviewer; combine roles for small tables. Both presenters circulate and facilitate; there is no separate floor facilitator.

## Local demo and recovery

Participants need no laptop, YAML or Kubernetes experience. Run the local reference only when `demo.py --check` reports `ready: true` with Kyverno CLI 1.19.1. It compiles supplied source and runs offline fixtures; it does not call a model, open a PR or change a cluster.

If preflight or the demo fails, stop troubleshooting and use hidden slides 33–34: “These are recorded fixture results, not a fresh cluster run.” Keep the room moving. Never show API keys or environment files. If five minutes behind at the recorded-finding section, use the compressed schedule in the co-presenter cards; preserve the independent review and recovery writing time.

Before calling room delivery verified, complete the 60-minute rehearsal with both presenters, sealed-page handoffs, fallback transition and venue display check. Those checks remain outstanding.
