# SC2632 co-presenter runbook

## The insight the audience should test

**A model decision, a policy test and an operational outcome are different evidence.** A valid policy can omit the required control. A passing fixture suite can miss an API path. An approved control can break recovery. Each round asks the table to identify which evidence is still missing before granting authority.

This makes the session useful across roles. Platform engineers leave with negative-test ideas and protected policy-engine identities. Incident responders leave with evidence/containment ordering and capacity checks. Governance and leadership participants leave with verified approval, scope, expiry and recovery criteria. Everyone produces an intent-to-control coverage record and a decision they can defend.

The exercise takes place on a shared production Kubernetes platform. The affected service remains operational and the extent of compromise is uncertain. Teams document scoped containment, essential dependencies, evidence and recovery authority. Workload names are retained from the fixtures for traceability. The model comparison supports discussion of delegation and review requirements; it does not establish a preferred model class.

## Materials and room mechanics

- Use ../2026-10-13/SC2632-session-four-cases.pptx and ../2026-10-13/PARTICIPANT-PACK.pdf. The deck has 30 main slides and six hidden backup slides, with timed speaker notes. The original submission copy is retained. Slides 25-26 now use the recorded trained-model proposal review, and the cost backup is hidden. Use tabletop/congress-2026/CO-PRESENTER-CARDS.md for prompts and tabletop/congress-2026/REHEARSAL.md for release checks.
- Print one ../2026-10-13/REVIEW-SCORECARD.pdf per table; use 12 core points plus up to three independent-review points. The rubric rewards defended evidence, not the strictest quarantine level.
- Print two copies of participant pages 1-5 per table and one or two copies of pages 6-7 (one shared two-page decision record). Print two copies of page 8 behind a sealed "Round 3" cover, and two copies of page 9 behind a sealed "Later finding" cover. Keep the record together; do not duplex a record page with a sealed update. All four cases remain available for team choice.
- Use the existing tabletop/print/vote-cards.pdf if wanted, or let a table lead speak its vote. Print two copies of ../2026-10-13/CONTROL-REVIEW.pdf page 1 per table and one copy of page 2 behind a sealed review-findings cover. Keep MODEL-DECISION-REVIEW.pdf as an optional backup exercise. The independent review needs a written disposition and acceptance evidence; no external polling system is necessary.
- The original table-01 through table-12 envelopes and old room clock assume assigned A/B/C cases. Do not combine their assignment instructions with the new four-choice pack. The new kit is a separate coherent session variant.
- Milind Gunjan and Vivek Mayuranathan co-present. Share the briefing, demonstration and debrief; alternate table support during exercises. Allow 45 minutes for setup if the venue permits, as the organizer described. Use a separate countdown timer and the runbook below; the old screen has different segment timing.
- The authorized curated source and downloads are public at https://github.com/mgunjan/sc2632-tabletop. The original project retains its private visibility. Slide 30 and the participant footers display the public address. Use the public README for the no-key take-home demo; preserve sealed-evidence timing in the room.

## The hour

| Minutes | Slides | Lead | Activity and observable output |
|---|---|---|---|
| 00–02:30 | 1–4 | Milind | AI proliferation hook, Two AI Shifts (Agents as Workloads vs Policy Writers), cluster map & 4 control layers |
| 02:30–04:30 | 5–6 | Vivek | 4-stage Python decision loop, provider data boundary and fail-open vs fail-closed defaults |
| 04:30–06:15 | 7–8 | Milind | 45s compiler walkthrough, requirement coverage ledger (`readiness.json`) and RBAC handoff |
| 06:15–07:15 | 9 | Vivek | Quarantine Mode (Q0–Q3) implementation and separate operator actions |
| 07:15–11 | 10–12 | Vivek & Milind | Pack orientation, 30s default case by table number (`1,5,9→A · 2,6,10→B · 3,7,11→C · 4,8,12→D`), constraint & roles on p. 6 |
| 11–15 | 13 | Milind & Vivek | Team writes intent, preserved dependency and non-admission handoff on page 6 |
| 15–19 | 14 | Vivek & Milind | Proposal disposition (`APPROVE/MODIFY/REJECT/ESCALATE`) and missing acceptance test |
| 19–22 | 15 | Milind & Vivek | Urgent exception inject: verify authority, scope, human owner and hard TTL |
| 22–26 | 16 | Vivek & Milind | Rollout mode (`Audit/Warn/Deny`) per control, promotion trigger and cleanup controller RBAC |
| 26–34 | 17 | Vivek & Milind | Open Sealed Page 8 at minute 27 and write ordered Q0–Q3 containment plan on page 7 |
| 34–38 | 18 | Milind & Vivek | Open Sealed Page 9 and revise or defend the plan beside the original on page 7 |
| 38–44 | 19–23 | Milind (1–2), Vivek (3–4) | Four recorded k3s lab traps (predict before reveal) and confirming tests |
| 44–45 | 24 (33 optional) | Vivek | Case comparison and locked Case D copied-credential prediction |
| 45–48 | 25 | Vivek & Milind | Independent trained-model proposal audit (`CONTROL-REVIEW.pdf` page 1) |
| 48–49 | 26 | Milind & Vivek | Open Sealed `CONTROL-REVIEW.pdf` page 2 (`6/6 PASS` yet `INCOMPLETE_PROPOSAL`) |
| 49–50 | 27 | Milind | Model speed vs. reviewer economics (`$2/min` engineer review vs `$0.038` API tokens) |
| 50–54 | 28 | Milind & Vivek | Recovery exit criteria, verification tests and lifting authority on page 7 |
| 54–60 | 29–30 | Both | Worked Case A debrief, 15-point scorecard tally, Monday action and Q&A |

## Technical briefing before the cases

The room sees the stakes and the internals before selecting a scenario or making a team decision. Slides 2–9 establish the operational context and actual architecture: the Two Operational Traps (Green-PR Illusion vs. Containment Self-Sabotage), the shared workload platform diagram (`cluster-map.png`), Falco/audit evidence, a fixed Python decision loop, provider-visible task strings, typed choices and uncertainty defaults, deterministic templates and Kyverno simulation, an independently bound requirement ledger, and separate Quarantine mechanisms. Use [TECHNICAL-BRIEF.md](../../tabletop/congress-2026/TECHNICAL-BRIEF.md) and the co-presenter cards for the implementation and 4 consolidated speaker blocks (`Milind 1–4`, `Vivek 5–6`, `Milind 7–8`, `Vivek 9`).

The forty-five-second compiler walkthrough occurs at 04:30, using a supplied reference spec. Pre-open the generated policy, local PR.md and readiness result; use them if the command cannot finish in its bounded deadline. The model receives no call in this path, no GitHub PR opens and no cluster change occurs. At 05:15 expand the single privilege requirement to the whole-intent ledger. Do not consume participant writing time to repeat the demo after Round 1.

Falco rules passed validation, but live detection and an alert-to-response integration remain unverified. The incident alerts are supplied facts. On the optional model path, unclear dependencies can retain a proposed allowance and require review. Typed choices and a 0.6 cutoff are not calibrated deployment assurance. Process credentials still require separate least-privilege enforcement. Quarantine levels group reviewed manifests and operator actions; people apply and verify every control.

Assignment begins at 07:15, fast-start case selection at 08:00 (using the default table-number mapping `Tables 1,5,9 → Case A · Tables 2,6,10 → Case B · Tables 3,7,11 → Case C · Tables 4,8,12 → Case D`, or swap within 30 seconds) and setup writing at 09:45. Round 1 retains four minutes from 11:00 to 15:00. Proposal review gets four minutes and temporary access three; later sealed reveals at minutes 27, 34 and 48, recovery and the 60-minute finish retain their existing positions.

Attendees can use ordinary security language while professionals inspect exact identities, request scope, payloads and authority. Scores assess decisions and evidence, not syntax or vocabulary recall. A ready table can distinguish what crosses the provider boundary, what the agent can propose, who deploys and which layer can enforce the requirement.

## The independent proposal review

Use ../2026-10-13/CONTROL-REVIEW.pdf. Vivek opens the task; Milind displays the recorded proposal. Give tables three minutes to record a disposition, outstanding requirement/owner, acceptance evidence and rollback condition. A team may justify a reviewed, bounded subset while escalating the remaining exposure. Keep page 2 sealed until choices are recorded.

At 48 minutes reveal the independent ledger: INCOMPLETE_PROPOSAL. The six fixed privilege CREATE tests pass, but the model chose a privilege control for the network requirement and the rollout/expiry requirement. Kubernetes API access remains unresolved. Ask one table to defend its authority decision and identify the actual CNI, RBAC or operations owner. Award up to three independent-review points for limited test scope, enforcement owner/evidence, and a justified authority boundary. These replace the old model-choice bonus; they do not add points or minutes.

The scores were recorded after a local Laya head fine-tune on 480 synthetic examples. Separate synthetic calibration did not establish reliability for the incident cases. The runtime-order 33-choice regression result stayed 16/33; the cutoff accepted 21 trained answers with six wrong, versus two accepted base answers. The reviewed workflow takes median 0.975 seconds but remains incomplete. No API charge; local compute unpriced. This example was selected after failure for teaching, not a controlled human-versus-model benchmark.

At 49 minutes show the historical Jev/Claude/zero-shot-Laya comparison for one minute. It uses its unchanged frozen inputs and option order. Jev 30/33 versus Claude 32/33 is inconclusive (paired p=0.50). Their three-run proposal medians were 1.82 seconds/$0.000191 and 24.18 seconds/$0.037952. Zero-shot Laya's 0.41-second workflow generated no guardrail. These exclude human review and deployment. Keep historical and trained configurations separate. OpenAI has an offline-tested adapter but no authenticated result.

The optional original three-case expert challenge remains available in MODEL-DECISION-REVIEW.pdf for Q&A or a separate practice run. It does not run in addition to the new review during this hour. Preserve its label disputes and raw-score/delegation distinction.

The [reference control library](../../controls/README.md) supplies stable IDs, coverage limits, test references, owners, proposed exception limits and platform evidence requirements. Model selection, policy behavior and containment coverage require separate evidence.

## Dependable compiler demonstration

Run from the repository root in an environment with PyYAML, jsonschema and Kyverno CLI 1.19.1. Use the durable .venv-session environment and the locally verified Kyverno CLI. Run the commands with that environment on PATH; missing dependencies fail preflight before proposal generation.

```bash
python3 tabletop/congress-2026/demo.py --check
python3 tabletop/congress-2026/demo.py --mode reference --scenario a --out output/congress-2026/reference-demo-01
```

If Kyverno is outside the shell PATH, add `--kyverno` with the actual executable path to both preflight and run commands; see the presenting-Mac example in tabletop/congress-2026/REHEARSAL.md. Preflight reports that path and checks exact version 1.19.1.

Before the session, open one generated privilege policy, the local PR.md and readiness.json under a successful reference output. At 04:30 say **"The supplied spec is a reference answer. The compiler and admission simulation run now."** Use the 45-second walkthrough to identify ACG-POD-001, the payments namespace, Pod CREATE coverage, regular/init containers and explicit allowPrivilegeEscalation=false. Move to the prepared policy immediately if the command cannot finish within its allotted time. At 05:15, slide 8 expands to the four-clause requirement ledger: six privilege checks pass while API access and other requirements still need their own evidence and human disposition. The output is a local review proposal, not a GitHub PR opened automatically.

Teams choose cases and roles after this briefing. Their proposal dispositions belong in the 15–19 review round; the recorded trained-model challenge belongs at 45–48. Use the case excerpts for the exception and rollout rounds. The opening has no additional workflow, readiness vote or directory tour. REVIEW_REQUIRED retains human disposition and disables automatic promotion.

For a separate enforcement rehearsal, a human can apply the reviewed privilege policy on the marked disposable lab and demonstrate server-dry-run rejection of a privileged Pod alongside admission of a compliant Pod. The planned hour uses recorded lab consequences at 38–45; it contains no additional live cluster enforcement segment. The original Strands launcher uses generator/demo_gate.py and its frozen model still fails eligibility. Use the bounded reference compiler for the opening and authentic replay for a separately rehearsed alternative or backup. The presenting-Mac enforcement record is in ../2026-10-13/live-rehearsal/.

The original standalone situation display is tabletop/deck/anim/situation.html. It is a redrawn lab recording, not a new live model or cluster result. The new submission deck uses static lab question images with explanatory notes, so it works without embedded video playback. Supply the visible technical facts before asking for a response and confirming test, then reveal each recorded observation. These discussions are ungraded and do not depend on recall of Kubernetes semantics. Use the animated display only after local browser and projector rehearsal.

## Debrief probes

| Case | Probe | Useful consequence |
|---|---|---|
| A | Did the PR implement the whole intent, and is the compromise limited to one Pod? | Add an explicit coverage gate and validate all affected replicas; preserve evidence before replacement. |
| B | Can admission see the unsafe tool call, and whose identity does the assistant use? | Repair tool/input authority and identity scope; an approved image does not establish safe tool behavior. |
| C | Did the guardrail stop the agent, or merely change who executes its request? | Verify the human approval path and narrow standing RBAC; freeze needs an authority boundary the agent cannot alter. |
| D | Would a network quarantine stop a credential used elsewhere? | Revoke/narrow authorization, identify exposed credentials and coordinate rotation with availability. |

During Round 3, D tables lock a copied-credential prediction before minute 34. At 44–45 read one original prediction and reveal the status-only October 13 lab result (backup 33 or transcript). The old token still reads synthetic Secrets after Pod network quarantine; narrowing its broad binding denies outside reads while preserving one required named Secret GET. Replacement and old bound-token revocation are tested separately. Stand-in health is not production metrics delivery, and external application-key rotation remains required. If no table chose D, collect an ungraded prediction before displaying slide 24, then compare it with the separate lab record. This replaces part of the existing case comparison; it adds no minutes or main slides.

The review examines assumptions about: intent coverage, API subresource, shared identity, human approval, additive network allows or recovery capacity. Ask tables to name the boundary, the evidence that checks it and the owner who can authorize crossing it.

## Before October 26

The gate mismatch and confidence validation are remediated. The agent writes staged manifests, provenance, a prepared-intent requirement ledger and focused independent privilege tests. Every requirement still needs human disposition; no deployment approval is implemented. Keep frozen evaluation labels unchanged and collect independently reviewed, held-out incidents. The presenting-Mac lab now has actual e2e evidence; exception lifecycle evidence is separate. Case D now has a separately executed synthetic RBAC/CNI/credential record. Finish the human hour and native display check; authorized public source distribution is verified. See the October 13 evidence and RUNTIME-REMEDIATION.md for their distinct scopes.

## Review rubric and demonstration choice

Use ../2026-10-13/REVIEW-SCORECARD.pdf: 12 core points plus up to three independent-review points. Require a written reason/evidence for each point; a co-presenter checks a sample using tabletop/congress-2026/SCORING-ANCHORS.md. Score acceptance evidence specified in the paper plan. Holding unverified authority earns credit; do not require or reward invented approvals or executed outcomes. The bonus evaluates test scope, enforcement owner/evidence and justified authority. A defensible bounded approval or escalation can earn points; there is no required vote. For equal scores, compare the evidence each team would require to revise the containment plan. At 54–55 use slide 29 and tabletop/congress-2026/WORKED-DECISION.md to trace an illustrative Case A paper plan through new evidence and recovery tests. At 55–57 tally points, hear two short reports and document a requirement, owner and verification step in each participant’s environment. The example is not executed containment or the required answer.

Best default for this submission: reference-spec compilation and fixture admission, with recorded model runs available for replay. The recorded Jev/Claude outputs and failed local-model outputs are authentic; label them as recordings. The isolated presenting-Mac lab has actual e2e evidence; repeat preflight on the day. A reviewed server dry-run can demonstrate admission with a positive control and rollback plan. Venue networking, projector and human delivery remain separate checks.

Optional live AI segment: use Jev on the prepared Scenario A, show its local proposal and the four dependency escalations, then show the independently tested reference artifact. This is a bounded non-deploying proposal demonstration. Claude can offer a second proposal or interpretation, but is not a calibrated automatic fallback; Laya is a useful fast-but-incomplete comparison, not the default enforcement demo. Avoid arbitrary audience intent driving enforcement and avoid the original health-only Decider live path.

A one-run Jev rehearsal can use a fresh run tag; the script refuses existing output rather than overwriting evidence:

```bash
python3 tabletop/congress-2026/demo.py --mode jev --env-file .env.jev --out output/congress-2026/jev-live-demo-01 --deadline 15
```

The script runs fixture-based proposal generation, not cluster deployment. Open proposal/PR.md and the policy files under the chosen output directory. If the deadline expires, stop and use the pre-opened reference artifact or prepared slides. Use the verified public source and downloads for attendee resources.

## Current professional framing

Use tabletop/congress-2026/INCIDENT-BRIEF.md as the current incident context. The original financial story, assigned three-case envelopes and room clock are legacy materials. Retain all frozen benchmark wording and labels, including the earlier business context, as historical inference evidence. Do not rewrite recorded results to match the workshop narrative. The review rubric evaluates documented reasoning; it does not certify security or reward the most restrictive posture.
